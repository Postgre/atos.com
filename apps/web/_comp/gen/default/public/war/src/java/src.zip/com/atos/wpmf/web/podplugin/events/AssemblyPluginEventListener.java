package com.atos.wpmf.web.podplugin.events;

public interface AssemblyPluginEventListener {

}
