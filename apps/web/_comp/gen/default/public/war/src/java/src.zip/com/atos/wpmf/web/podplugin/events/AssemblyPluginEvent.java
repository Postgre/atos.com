package com.atos.wpmf.web.podplugin.events;

import java.util.EventObject;

public class AssemblyPluginEvent extends EventObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public AssemblyPluginEvent(Object source) {
		super(source);
	}

}
