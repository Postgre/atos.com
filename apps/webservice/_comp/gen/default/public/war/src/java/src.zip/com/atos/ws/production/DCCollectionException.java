package com.atos.ws.production;

public class DCCollectionException extends Exception {

	public DCCollectionException(String message) {
		super(message);
	}

}
