package com.atos.ws.production;

public class PodException extends Exception {

	public PodException(String message) {
		super(message);
	}

}
